package pdm.mdbg.RegisterLogin.LogIn;


import android.content.Intent;
import android.database.Cursor;
import android.os.Build;
import android.os.Bundle;
import android.support.annotation.RequiresApi;
import android.support.v4.app.Fragment;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Objects;

import pdm.mdbg.Backend.Database.Database;
import pdm.mdbg.Backend.Session.Session;
import pdm.mdbg.Frontend.AccountActivity;
import pdm.mdbg.R;

/**
 * A simple {@link Fragment} subclass.
 */
public class LogInFragment extends Fragment {
    Database MovieDB;
    EditText login_email, login_password;
    Button btn_login;
    String email,password;
    private Session session;

    public LogInFragment() {
        // Required empty public constructor
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View SignIn = inflater.inflate(R.layout.fragment_log_in, container, false);
        final Intent next = new Intent(getContext(), AccountActivity.class);
        session = new Session(getContext());
        if (!session.getEMAIL().isEmpty()) {
            startActivity(next);
        }else {
            MovieDB = new Database(getContext());
            login_email = (EditText) SignIn.findViewById(R.id.login_email);
            login_password = (EditText) SignIn.findViewById(R.id.login_password);
            btn_login = (Button) SignIn.findViewById(R.id.btn_login);
            btn_login.setOnClickListener(new View.OnClickListener() {
                @RequiresApi(api = Build.VERSION_CODES.KITKAT)
                @Override
                public void onClick(View view) {
                    email = login_email.getText().toString();
                    password = login_password.getText().toString();
                    Cursor result = MovieDB.checkEmail(email);
                    Cursor userData = MovieDB.checkEmail(email);
                    if (result.getCount() == 0) {
                        Toast.makeText(getContext(), "This E-Mail is not registered yet!", Toast.LENGTH_LONG).show();
                    } else {
                        if (TextUtils.isEmpty(password) || password.length() < 8) {
                            Toast.makeText(getContext(), "Don't forget to fill the password field!", Toast.LENGTH_LONG).show();
                        } else {
                            StringBuffer buffer = new StringBuffer();
                            while (result.moveToNext()) {
                                buffer.append(result.getString(4));
                            }
                            if (Objects.equals(buffer.toString(), password)) {
                                StringBuffer bufferData = new StringBuffer();
                                while (userData.moveToNext()) {
                                    bufferData.append(userData.getString(0));
                                }
                                session.setEMAIL(email);
                                session.setID(bufferData.toString());
                                startActivity(next);

                                Toast.makeText(getContext(), "Welcome!", Toast.LENGTH_LONG).show();
                            } else {
                                Toast.makeText(getContext(), "Something went wrong, try again!", Toast.LENGTH_LONG).show();
                            }
                        }
                    }
                }
            });
        }
        return SignIn;
    }
}
