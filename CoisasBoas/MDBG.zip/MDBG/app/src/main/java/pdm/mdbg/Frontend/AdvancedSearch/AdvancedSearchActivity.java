package pdm.mdbg.Frontend.AdvancedSearch;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.InputFilter;
import android.text.Spanned;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

import pdm.mdbg.Backend.Database.Database;
import pdm.mdbg.Backend.Session.Session;
import pdm.mdbg.Frontend.Search.AdvancedResultActivity;
import pdm.mdbg.Frontend.Search.ByGenreResultActivity;
import pdm.mdbg.R;

public class AdvancedSearchActivity extends AppCompatActivity {
    Session session;
    Database MovieDB;
    EditText year, gte, lte;
    RadioGroup sort;
    RadioButton asc, desc;
    Button search;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_advanced_search);
        setTitle("Advanced Search");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        Toast.makeText(getApplicationContext(), "All fields are optional!", Toast.LENGTH_LONG).show();
        year = (EditText)findViewById(R.id.releaseyear);
        gte = (EditText)findViewById(R.id.gte);
        lte = (EditText)findViewById(R.id.lte);
        sort = (RadioGroup)findViewById(R.id.sort);
        asc = (RadioButton)findViewById(R.id.asc);
        desc = (RadioButton)findViewById(R.id.desc);
        search = (Button)findViewById(R.id.btn_searc_adv);
        gte.setFilters(new InputFilter[]{ new InputMinMax(0, 10)});
        lte.setFilters(new InputFilter[]{ new InputMinMax(1, 10)});

        search.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String year_release = year.getText().toString();
                if (year_release.equals("")){
                    year_release = "2017";
                }
                if ((Integer.parseInt(year_release)) > 2017){
                    Toast.makeText(getApplicationContext(), "Wtf? Where do you live? The max year is 2017!", Toast.LENGTH_LONG).show();
                }else{
                    String URL_DATA = "https://api.themoviedb.org/3/discover/movie?api_key=51f4b2a5afbbe4dba72a114dd0f06f5f";
                    URL_DATA = URL_DATA.concat("&primary_release_year="+year_release);
                    if(!gte.getText().toString().equals("")){
                        URL_DATA = URL_DATA.concat("&vote_average.gte=" + gte.getText().toString());
                    }
                    if(!lte.getText().toString().equals("")){
                        URL_DATA = URL_DATA.concat("&vote_average.lte=" + lte.getText().toString());
                    }
                    if(desc.isChecked()){
                        URL_DATA = URL_DATA.concat("&sort_by=vote_average.desc");
                    }
                    if(asc.isChecked()){
                        URL_DATA = URL_DATA.concat("&sort_by=vote_average.asc");
                    }
                    Intent intent = new Intent(view.getContext(), AdvancedResultActivity.class);
                    intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    intent.putExtra("link", URL_DATA);
                    startActivity(intent);
//                    Toast.makeText(getApplicationContext(), URL_DATA, Toast.LENGTH_LONG).show();
                }
            }
        });
    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()){
            case android.R.id.home:
                this.finish();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    public class InputMinMax implements InputFilter {
        private double minValue;
        private double maxValue;

        public InputMinMax(double minVal, double maxVal) {
            this.minValue = minVal;
            this.maxValue = maxVal;
        }

        @Override
        public CharSequence filter(CharSequence source, int start, int end, Spanned dest, int dStart, int dEnd) {
            try {
                // Remove the string out of destination that is to be replaced
                String newVal = dest.toString().substring(0, dStart) + dest.toString().substring(dEnd, dest.toString().length());
                newVal = newVal.substring(0, dStart) + source.toString() + newVal.substring(dStart, newVal.length());
                double input = Double.parseDouble(newVal);

                if (isInRange(minValue, maxValue, input)) {
                    return null;
                }
            } catch (NumberFormatException e) {
                e.printStackTrace();
            }
            return "";
        }

        private boolean isInRange(double a, double b, double c) {
            return b > a ? c >= a && c <= b : c >= b && c <= a;
        }
    }
}
