package pdm.mdbg.Backend.Items;

/**
 * Created by andremelo on 22/01/2017.
 */

public class FavDetailsItem {
    private String user_rating;
    private String user_date;
    private String user_status;
    private String movie_title;
    private String movie_date;
    private String movie_overview;
    private String movie_rating;
    private String movie_backdrop;

    public FavDetailsItem(String movie_title, String movie_date, String movie_overview, String movie_rating, String movie_backdrop, String user_rating, String user_date,String user_status) {
        this.movie_title = movie_title;
        this.movie_date = movie_date;
        this.movie_overview = movie_overview;
        this.movie_rating = movie_rating;
        this.movie_backdrop = movie_backdrop;
        this.user_rating = user_rating;
        this.user_date = user_date;
        this.user_status = user_status;
    }

    public String getMovie_title() {
        return movie_title;
    }

    public String getMovie_date() {
        return movie_date;
    }

    public String getMovie_overview() {
        return movie_overview;
    }

    public String getMovie_poster() {
        String link = "http://image.tmdb.org/t/p/w780";
        return link+movie_backdrop;
    }
    public String getMovie_rating() {
        return movie_rating+" / 10";
    }

    public String getUser_rating() {
        return user_rating;
    }

    public String getUser_date() {
        return user_date;
    }

    public String getUser_status() {
        return user_status;
    }

}
