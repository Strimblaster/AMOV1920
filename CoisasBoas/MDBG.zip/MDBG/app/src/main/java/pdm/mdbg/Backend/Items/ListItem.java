package pdm.mdbg.Backend.Items;

/**
 * Created by andremelo on 21/01/2017.
 */

public class ListItem {
    private String movie_id;
    private String movie_thumb;
    private String movie_title;

    public ListItem(String movie_thumb, String movie_id, String movie_title) {
        this.movie_thumb = movie_thumb;
        this.movie_id = movie_id;
        this.movie_title = movie_title;
    }

    public String getMovie_thumb() {
        String link = "http://image.tmdb.org/t/p/w500";
        return link+movie_thumb;
    }

    public String getMovie_id() {
        return movie_id;
    }
    public String getMovie_title() {
        return movie_title;
    }
}
