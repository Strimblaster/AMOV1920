package pdm.mdbg.Backend.Items;

/**
 * Created by andremelo on 21/01/2017.
 */

public class DetailsItem {
    private String movie_title;
    private String movie_date;
    private String movie_overview;
    private String movie_rating;
    private String movie_backdrop;

    public DetailsItem(String movie_title, String movie_date, String movie_overview, String movie_rating, String movie_backdrop) {
        this.movie_title = movie_title;
        this.movie_date = movie_date;
        this.movie_overview = movie_overview;
        this.movie_rating = movie_rating;
        this.movie_backdrop = movie_backdrop;
    }

    public String getMovie_title() {
        return movie_title;
    }

    public String getMovie_date() {
        return movie_date;
    }

    public String getMovie_overview() {
        return movie_overview;
    }

    public String getMovie_poster() {
        String link = "http://image.tmdb.org/t/p/w780";
        return link+movie_backdrop;
    }
    public String getMovie_rating() {
        return movie_rating+" / 10";
    }
}