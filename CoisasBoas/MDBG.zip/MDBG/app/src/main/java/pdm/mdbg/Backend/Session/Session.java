package pdm.mdbg.Backend.Session;

import android.content.Context;
import android.content.SharedPreferences;
import android.preference.PreferenceManager;

/**
 * Created by andremelo on 21/01/2017.
 */

public class Session {


    private SharedPreferences prefs;

    public Session(Context cntx) {
        // TODO Auto-generated constructor stub
        prefs = PreferenceManager.getDefaultSharedPreferences(cntx);
    }

    public void setID(String id) {
        prefs.edit().putString("id", id).apply();
    }
    public String getID() {
        return prefs.getString("id","");
    }
    public void setMovieID(String id) {
        prefs.edit().putString("movie_id", id).apply();
    }
    public String getMovieID() {
        return prefs.getString("movie_id","");
    }
    public void setMovieTitle(String title) {
        prefs.edit().putString("movie_title",title).apply();
    }
    public String getMovieTitle() {
        return prefs.getString("movie_title","");
    }
    public void setMovieThumb(String movie_thumb) {
        prefs.edit().putString("movie_thumb",movie_thumb).apply();
    }
    public String getMovieThumb() {
        String thumb = prefs.getString("movie_thumb","");
        return thumb;
    }

    public void setEMAIL(String email) {
        prefs.edit().putString("email", email).apply();

    }

    public String getEMAIL() {
        String email = prefs.getString("email","");
        return email;
    }

    public void logout() {
        SharedPreferences.Editor editor = prefs.edit();
        editor.clear();
        editor.apply();
    }

    public void setSearch(String search) {
        prefs.edit().putString("search", search).apply();
    }
    public String getSearch() {
        String search = prefs.getString("search","");
        return search;
    }
}
