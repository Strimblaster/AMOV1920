package pdm.mdbg.Backend.Database;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * Created by andremelo on 21/01/2017.
 */

public class Database extends SQLiteOpenHelper {
    private static final String DB_NAME = "MyMoviesDB";
    private static final String TABLE_USERS = "Users";
    private static final String TABLE_FAVS = "Favorites";
    private static final String TABLE_USER_FAVS = "Users_Favorites";

    //Users Table Columns
    private static final String USER_COL_1 = "id";
    private static final String USER_COL_2 = "name";
    private static final String USER_COL_3 = "surname";
    private static final String USER_COL_4 = "email";
    private static final String USER_COL_5 = "password";

    //Favorites Table Columns
    private static final String FAVS_COL_1 = "id";
    private static final String FAVS_COL_2 = "movie_id";


    //Users_Favorites Table Columns
    private static final String UFAVS_COL_1 = "id";
    private static final String UFAVS_COL_2 = "user_id";
    private static final String UFAVS_COL_3 = "movie_id";
    private static final String UFAVS_COL_4 = "movie_thumb";
    private static final String UFAVS_COL_5 = "rating";
    private static final String UFAVS_COL_6 = "status";
    private static final String UFAVS_COL_7 = "date";

    public Database(Context context) {
        super(context, DB_NAME, null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("create table " +  TABLE_USERS + " (ID INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,NAME TEXT NOT NULL,SURNAME TEXT NOT NULL,EMAIL TEXT NOT NULL UNIQUE,PASSWORD TEXT NOT NULL)");
        db.execSQL("create table " +  TABLE_FAVS + " (ID INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,MOVIE_ID INTEGER NOT NULL)");
        db.execSQL("create table " +  TABLE_USER_FAVS + " (ID INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,USER_ID INTEGER NOT NULL,MOVIE_ID INTEGER NOT NULL, MOVIE_THUMB TEXT,RATING REAL,STATUS TEXT,DATE NUMERIC, FOREIGN KEY (user_id) REFERENCES Users(id),FOREIGN KEY (movie_id) REFERENCES Favorites(id))");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int i, int i1) {
        db.execSQL("DROP TABLE IF EXISTS "+TABLE_USERS);
        db.execSQL("DROP TABLE IF EXISTS "+TABLE_FAVS);
        db.execSQL("DROP TABLE IF EXISTS "+TABLE_USER_FAVS);
        onCreate(db);
    }
    public boolean addData(String name,String surname, String email,String password){
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(USER_COL_2,name);
        contentValues.put(USER_COL_3,surname);
        contentValues.put(USER_COL_4,email);
        contentValues.put(USER_COL_5,password);
        long result = db.insert(TABLE_USERS,null,contentValues);
        return result != -1;
    }
    public Cursor checkEmail(String email){
        SQLiteDatabase db = this.getWritableDatabase();
        return db.rawQuery("select * from "+TABLE_USERS+" where "+USER_COL_4+"=\""+email+"\"",null);
    }
    public Cursor getFavs(String user_id){
        SQLiteDatabase db = this.getWritableDatabase();
        return db.rawQuery("select * from "+TABLE_USER_FAVS+" where "+UFAVS_COL_2+"=\""+user_id+"\" order by "+UFAVS_COL_5+" desc, "+UFAVS_COL_7+" desc",null);
    }
    public String addFav(String user_id, String movie_id, String movie_thumb, String movie_rating, String movie_state){
        Date cDate = new Date();
        String fDate = new SimpleDateFormat("dd-MM-yyyy").format(cDate);
        boolean movieExists = checkMovieFav(movie_id);
        SQLiteDatabase db = this.getWritableDatabase();
        if (movieExists){
            boolean movieUserFavExists = checkMovieAFav(user_id,movie_id);
            if (movieUserFavExists) {
                removeFav(user_id,movie_id);
                return "Movie removed from favorites!";
            }else{
                ContentValues contentValues2 = new ContentValues();
                contentValues2.put(UFAVS_COL_2, user_id);
                contentValues2.put(UFAVS_COL_3, movie_id);
                contentValues2.put(UFAVS_COL_4, movie_thumb);
                contentValues2.put(UFAVS_COL_5, movie_rating);
                contentValues2.put(UFAVS_COL_6, movie_state);
                contentValues2.put(UFAVS_COL_7, fDate);
                db.insert(TABLE_USER_FAVS, null, contentValues2);
                return "Movie added to favorites with success!";
            }
        }else {
            ContentValues contentValues = new ContentValues();
            contentValues.put(FAVS_COL_2, movie_id);
            db.insert(TABLE_FAVS, null, contentValues);
            ContentValues contentValues2 = new ContentValues();
            contentValues2.put(UFAVS_COL_2, user_id);
            contentValues2.put(UFAVS_COL_3, movie_id);
            contentValues2.put(UFAVS_COL_4, movie_thumb);
            contentValues2.put(UFAVS_COL_5, movie_rating);
            contentValues2.put(UFAVS_COL_6, movie_state);
            contentValues2.put(UFAVS_COL_7, fDate);
            db.insert(TABLE_USER_FAVS, null, contentValues2);
            return "Movie added to favorites with success!";
        }
    }
    public Cursor getMovieData(String user_id, String movie_id){
        SQLiteDatabase db = this.getWritableDatabase();
        return db.rawQuery("select * from "+TABLE_USER_FAVS+" where "+UFAVS_COL_3+"=\""+movie_id+"\" and "+UFAVS_COL_2+"=\""+user_id+"\";",null);
    }
    public boolean removeFav(String user_id, String movie_id) {
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor delete = db.rawQuery("DELETE FROM "+TABLE_USER_FAVS+" WHERE "+UFAVS_COL_2+"=\""+user_id+"\" AND "+UFAVS_COL_3+"=\""+movie_id+"\";",null);
        return delete.getCount() != 0;
    }

    private boolean checkMovieFav(String movie_id) {
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor result = db.rawQuery("select * from "+TABLE_FAVS+" where "+FAVS_COL_2+"=\""+movie_id+"\";",null);
        return result.getCount() != 0;
    }
    public boolean checkMovieAFav(String user_id, String movie_id) {
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor result = db.rawQuery("select * from "+TABLE_USER_FAVS+" where "+UFAVS_COL_2+"=\""+user_id+"\" and "+UFAVS_COL_3+"=\""+movie_id+"\";",null);
        return result.getCount() != 0;
    }
}