package pdm.mdbg.Backend.Adapters;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.squareup.picasso.Picasso;

import java.util.List;

import pdm.mdbg.Backend.Items.FavDetailsItem;
import pdm.mdbg.R;

/**
 * Created by andremelo on 22/01/2017.
 */

public class FavDetailsAdapter extends RecyclerView.Adapter<FavDetailsAdapter.ViewHolder>{
    private List<FavDetailsItem> FavDetailsItems;
    private Context context;
    public FavDetailsAdapter(List<FavDetailsItem> FavDetailsItems, Context context) {
        this.FavDetailsItems = FavDetailsItems;
        this.context = context;
    }
    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.fav_item,parent,false);
        return new ViewHolder(v);
    }

    @Override
    public void onBindViewHolder(ViewHolder holder, int position) {
        final FavDetailsItem listItem = FavDetailsItems.get(position);
        holder.movieTitleText.setText(listItem.getMovie_title());
        holder.movieDateText.setText(listItem.getMovie_date());
        holder.movieOverviewText.setText(listItem.getMovie_overview());
        holder.movieRatingText.setText(listItem.getMovie_rating());
        holder.user_rating.setText(listItem.getUser_rating());
        holder.user_date.setText(listItem.getUser_date());
        holder.user_status.setText(listItem.getUser_status());
        Picasso.with(context)
                .load(listItem.getMovie_poster())
                .into(holder.moviePoster);
    }

    @Override
    public int getItemCount() {
        return FavDetailsItems.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder{
        public TextView movieTitleText, movieDateText, movieOverviewText, movieRatingText, user_rating, user_date, user_status;
        public ImageView moviePoster;
        public LinearLayout linearLayout;

        public ViewHolder(View itemView) {
            super(itemView);
            movieTitleText = (TextView) itemView.findViewById(R.id.movie_title);
            movieDateText = (TextView) itemView.findViewById(R.id.movie_date);
            movieOverviewText = (TextView) itemView.findViewById(R.id.movie_overview);
            movieRatingText = (TextView) itemView.findViewById(R.id.movie_rating);
            moviePoster = (ImageView) itemView.findViewById(R.id.movie_backdrop);
            user_rating = (TextView) itemView.findViewById(R.id.user_rating);
            user_date = (TextView) itemView.findViewById(R.id.user_date);
            user_status = (TextView) itemView.findViewById(R.id.user_status);
            linearLayout = (LinearLayout) itemView.findViewById(R.id.itemLayoutMovieDetails);
        }
    }
}
