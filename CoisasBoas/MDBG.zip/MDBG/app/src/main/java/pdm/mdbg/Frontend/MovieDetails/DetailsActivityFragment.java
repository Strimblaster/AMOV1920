package pdm.mdbg.Frontend.MovieDetails;

import android.app.ProgressDialog;
import android.support.v4.app.Fragment;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

import pdm.mdbg.Backend.Adapters.DetailsAdapter;
import pdm.mdbg.Backend.Items.DetailsItem;
import pdm.mdbg.Backend.Session.Session;
import pdm.mdbg.R;

/**
 * A placeholder fragment containing a simple view.
 */
public class DetailsActivityFragment extends Fragment {
    private static final String URL_DATA = "https://api.themoviedb.org/3/movie/";
    private static final String URL_DATA2 = "?api_key=51f4b2a5afbbe4dba72a114dd0f06f5f&language=en-US";
    private RecyclerView recyclerView;
    private RecyclerView.Adapter adapter;
    private List<DetailsItem> listItems;
    Session session;

    public DetailsActivityFragment() {
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View details = inflater.inflate(R.layout.fragment_details, container, false);
        session = new Session(getContext());
        String id = session.getMovieID();
        recyclerView = (RecyclerView) details.findViewById(R.id.detailsRV);
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));
        listItems= new ArrayList<>();
        MovieDetails(id);
        return details;
    }
    private void MovieDetails(String id) {
        final ProgressDialog progressDialog = new ProgressDialog(getContext());
        progressDialog.setMessage("Loading...");
        progressDialog.show();

        StringRequest stringRequest = new StringRequest(Request.Method.GET, URL_DATA+id+URL_DATA2,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        progressDialog.dismiss();
                        try {
                            JSONObject jsonObject = new JSONObject(response);
                            DetailsItem item = new DetailsItem(
                                    jsonObject.getString("title"),
                                    jsonObject.getString("release_date"),
                                    jsonObject.getString("overview"),
                                    jsonObject.getString("vote_average"),
                                    jsonObject.getString("backdrop_path")
                            );
                            listItems.add(item);
                            adapter = new DetailsAdapter(listItems, getContext());
                            recyclerView.setAdapter(adapter);
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        progressDialog.dismiss();
                        Toast.makeText(getContext(), error.getMessage(), Toast.LENGTH_LONG).show();
                    }
                }
        );
        RequestQueue requestQueue = Volley.newRequestQueue(getContext());
        requestQueue.add(stringRequest);
    }
}
