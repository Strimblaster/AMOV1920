package pdm.mdbg.Backend.Adapters;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.squareup.picasso.Picasso;

import java.util.List;

import pdm.mdbg.Backend.Items.DetailsItem;
import pdm.mdbg.R;

/**
 * Created by andremelo on 21/01/2017.
 */

public class DetailsAdapter extends RecyclerView.Adapter<DetailsAdapter.ViewHolder> {

    private List<DetailsItem> detailsItems;
    private Context context;
    public DetailsAdapter(List<DetailsItem> detailsItems, Context context) {
        this.detailsItems = detailsItems;
        this.context = context;
    }
    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.movie_item,parent,false);
        return new ViewHolder(v);
    }

    @Override
    public void onBindViewHolder(ViewHolder holder, int position) {
        final DetailsItem listItem = detailsItems.get(position);
        holder.movieTitleText.setText(listItem.getMovie_title());
        holder.movieDateText.setText(listItem.getMovie_date());
        holder.movieOverviewText.setText(listItem.getMovie_overview());
        holder.movieRatingText.setText(listItem.getMovie_rating());
        Picasso.with(context)
                .load(listItem.getMovie_poster())
                .into(holder.moviePoster);
    }

    @Override
    public int getItemCount() {
        return detailsItems.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder{
        public TextView movieTitleText;
        public TextView movieDateText;
        public TextView movieOverviewText;
        public TextView movieRatingText;
        public ImageView moviePoster;
        public LinearLayout linearLayout;

        public ViewHolder(View itemView) {
            super(itemView);
            movieTitleText = (TextView) itemView.findViewById(R.id.movie_title);
            movieDateText = (TextView) itemView.findViewById(R.id.movie_date);
            movieOverviewText = (TextView) itemView.findViewById(R.id.movie_overview);
            movieRatingText = (TextView) itemView.findViewById(R.id.movie_rating);
            moviePoster = (ImageView) itemView.findViewById(R.id.movie_backdrop);
            linearLayout = (LinearLayout) itemView.findViewById(R.id.itemLayoutMovieDetails);
        }
    }
}

