package pdm.mdbg.Backend.Adapters;

import android.content.Context;
import android.content.Intent;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;

import com.squareup.picasso.Picasso;

import java.util.List;

import pdm.mdbg.Backend.Items.FavsItem;
import pdm.mdbg.Backend.Session.Session;
import pdm.mdbg.Frontend.AccountActivity;
import pdm.mdbg.Frontend.MovieDetails.DetailsActivity;
import pdm.mdbg.Frontend.MovieDetails.FavDetailsActivity;
import pdm.mdbg.R;

/**
 * Created by andremelo on 22/01/2017.
 */

public class FavsAdapter extends RecyclerView.Adapter<FavsAdapter.ViewHolder> {
    private List<FavsItem> favsItems;
    private Context context;
    private Session session;
    public FavsAdapter(List<FavsItem> favsItems, Context context) {
        this.favsItems = favsItems;
        this.context = context;
    }


    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view  = LayoutInflater.from(parent.getContext()).inflate(R.layout.list_item,parent,false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(ViewHolder holder, int position) {
        session = new Session(context);
        final String TAG = AccountActivity.class.getSimpleName();
        final FavsItem favitem = favsItems.get(position);
        Picasso.with(context)
                .load(favitem.getMovie_thumb())
                .into(holder.movieThumb);
        holder.linearLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String id = favitem.getMovie_id();
                Intent intent = new Intent(view.getContext(),FavDetailsActivity.class);
                session.setMovieID(id);
                context.startActivity(intent);
            }
        });
    }

    @Override
    public int getItemCount() {
        return favsItems.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        public ImageView movieThumb;
        public LinearLayout linearLayout;
        public ViewHolder(View itemView) {
            super(itemView);
            movieThumb = (ImageView) itemView.findViewById(R.id.movie_thumb);
            linearLayout = (LinearLayout) itemView.findViewById(R.id.listItemLayout);
        }
    }
}