package pdm.mdbg.Frontend.MovieDetails;

import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

import com.squareup.picasso.Picasso;

import pdm.mdbg.Backend.Database.Database;
import pdm.mdbg.Backend.Session.Session;
import pdm.mdbg.R;

public class FavDetailsActivity extends AppCompatActivity {
    Session session;
    Database MovieDB;
    String message, state;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_fav_details);
        session = new Session(getApplicationContext());
        MovieDB = new Database(getApplicationContext());
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        setTitle("My Favorite");
        FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (MovieDB.checkMovieAFav(session.getID(),session.getMovieID())){
                    MovieDB.removeFav(session.getID(),session.getMovieID());
                    Snackbar.make(view, "Movie removed from favorites!", Snackbar.LENGTH_LONG).setAction("Action", null).show();
                }else {
                    session = new Session(getApplicationContext());
                    AlertDialog.Builder builder = new AlertDialog.Builder(FavDetailsActivity.this);
                    View dialog = getLayoutInflater().inflate(R.layout.dialog, null);
                    final EditText rating = (EditText) dialog.findViewById(R.id.film_rate);
                    final ImageView image = (ImageView) dialog.findViewById(R.id.movie_image);
                    Picasso.with(getApplicationContext())
                            .load(session.getMovieThumb())
                            .into(image);
                    final RadioButton watched = (RadioButton) dialog.findViewById(R.id.watched);
                    final RadioButton watch = (RadioButton) dialog.findViewById(R.id.watch);
                    Button done = (Button) dialog.findViewById(R.id.btn_done);
                    builder.setView(dialog);
                    final AlertDialog alertDialog = builder.create();
                    alertDialog.show();
                    done.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {
                            alertDialog.hide();
                            String movie_rating = rating.getText().toString();
                            if (movie_rating.isEmpty()){
                                movie_rating = "0";
                            }
                            movie_rating = movie_rating.replace(",", "");
                            movie_rating = movie_rating.replace(".", "");
                            if (watch.isChecked()){
                                state = "Watch";
                            }else if(watched.isChecked()){
                                state = "Watched";
                            }
                            int foo = Integer.parseInt(movie_rating);
                            if (foo < 0 || foo > 10) {
                                Toast.makeText(getApplicationContext(), "Please fill the rating field with a value between 0 and 10!", Toast.LENGTH_LONG).show();
                            } else {
                                message = MovieDB.addFav(session.getID(), session.getMovieID(), session.getMovieThumb(), movie_rating, state);
                                Toast.makeText(getApplicationContext(), "Movie added to favorites with success!", Toast.LENGTH_LONG).show();
                            }
                        }
                    });
                }
            }
        });
    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()){
            case android.R.id.home:
                this.finish();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }
}
