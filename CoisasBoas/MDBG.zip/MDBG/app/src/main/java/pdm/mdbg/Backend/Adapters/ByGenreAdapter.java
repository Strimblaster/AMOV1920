package pdm.mdbg.Backend.Adapters;

import android.content.Context;
import android.content.Intent;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.List;

import pdm.mdbg.Backend.Items.ByGenreItem;
import pdm.mdbg.Frontend.Search.ByGenreResultActivity;
import pdm.mdbg.R;

/**
 * Created by andremelo on 22/01/2017.
 */

public class ByGenreAdapter extends RecyclerView.Adapter<ByGenreAdapter.ViewHolder>{
    private List<ByGenreItem> listItems;
    private Context context;
    public ByGenreAdapter(List<ByGenreItem> listItems, Context context) {
        this.listItems = listItems;
        this.context = context;
    }
    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view  = LayoutInflater.from(parent.getContext()).inflate(R.layout.genre_item,parent,false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(ViewHolder holder, int position) {
        final ByGenreItem listItem = listItems.get(position);
        holder.gender_name.setText(listItem.getGender_name());
        holder.linearLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String id = listItem.getGender_id();
                Intent intent = new Intent(view.getContext(), ByGenreResultActivity.class);
                intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                intent.putExtra("id", id);
                intent.putExtra("genre", listItem.getGender_name());
                context.startActivity(intent);
            }
        });
    }

    @Override
    public int getItemCount() {
        return listItems.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        public TextView gender_name;
        public LinearLayout linearLayout;
        public ViewHolder(View itemView) {
            super(itemView);
            gender_name = (TextView) itemView.findViewById(R.id.genre_name);
            linearLayout = (LinearLayout) itemView.findViewById(R.id.genreLayout);
        }
    }
}
