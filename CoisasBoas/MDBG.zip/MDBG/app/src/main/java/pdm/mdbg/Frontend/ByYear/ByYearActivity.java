package pdm.mdbg.Frontend.ByYear;

import android.app.ProgressDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

import pdm.mdbg.Backend.Adapters.ListAdapter;
import pdm.mdbg.Backend.Items.ListItem;
import pdm.mdbg.R;

public class ByYearActivity extends AppCompatActivity {
    EditText yearText;
    Button btn_search;
    private RecyclerView recyclerView;
    private RecyclerView.Adapter adapter;
    private List<ListItem> listItems;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_by_year);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        setTitle("Search by year");
        recyclerView = (RecyclerView) findViewById(R.id.byYearRV);
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new GridLayoutManager(getApplicationContext(), 2));
        btn_search = (Button) findViewById(R.id.btn_search);
        yearText = (EditText) findViewById(R.id.year_text);
        btn_search.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String search = yearText.getText().toString();
                if (search.length() != 4 ){
                    Toast.makeText(getApplicationContext(), "Search for a valid year please!", Toast.LENGTH_LONG).show();
                }else{
                    listItems= new ArrayList<>();
                    YearMovies(search);
                }
            }
        });
    }

    private void YearMovies(String search) {
        String URL_YEAR = "https://api.themoviedb.org/3/discover/movie?api_key=51f4b2a5afbbe4dba72a114dd0f06f5f&language=en-US&sort_by=popularity.desc&include_adult=false&include_video=false&page=1&primary_release_year="+search;
        StringRequest stringRequest = new StringRequest(Request.Method.GET, URL_YEAR,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        try {
                            JSONObject jsonObject = new JSONObject(response);
                            JSONArray array = jsonObject.getJSONArray("results");
                            for (int i = 0; i<array.length(); i++){
                                JSONObject o = array.getJSONObject(i);
                                ListItem item = new ListItem(
                                        o.getString("poster_path"),
                                        o.getString("id"),
                                        o.getString("title")
                                );
                                listItems.add(item);
                            }
                            adapter = new ListAdapter(listItems, getApplicationContext());
                            recyclerView.setAdapter(adapter);
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(getApplicationContext(), error.getMessage(), Toast.LENGTH_LONG).show();
                    }
                }
        );
        RequestQueue requestQueue = Volley.newRequestQueue(getApplicationContext());
        requestQueue.add(stringRequest);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()){
            case android.R.id.home:
                this.finish();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }
}
