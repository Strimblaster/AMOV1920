package pdm.mdbg.Frontend.MyFavorites;


import android.app.ProgressDialog;
import android.database.Cursor;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.widget.SwipeRefreshLayout;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;


import java.util.ArrayList;
import java.util.List;

import pdm.mdbg.Backend.Adapters.FavsAdapter;
import pdm.mdbg.Backend.Database.Database;
import pdm.mdbg.Backend.Items.FavsItem;
import pdm.mdbg.Backend.Session.Session;
import pdm.mdbg.Frontend.AccountActivity;
import pdm.mdbg.R;

/**
 * A simple {@link Fragment} subclass.
 */
public class MyFavoritesFragment extends Fragment {
    Session session;
    Database MovieDB;
    private RecyclerView recyclerView;
    private RecyclerView.Adapter adapter;
    private List<FavsItem> favsItems;
    SwipeRefreshLayout mSwipeRefreshLayout;
    TextView noData;
    private static final String TAG = AccountActivity.class.getSimpleName();
    public MyFavoritesFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View favs = inflater.inflate(R.layout.fragment_my_favorites, container, false);
        mSwipeRefreshLayout = (SwipeRefreshLayout) favs.findViewById(R.id.swipeContainer);
        mSwipeRefreshLayout.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {
                refreshContent();
            }
        });
        recyclerView = (RecyclerView) favs.findViewById(R.id.myFavoritesRV);
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new GridLayoutManager(getContext(), 2));
        recyclerView.invalidate();
        noData = (TextView) favs.findViewById(R.id.noDataText);
        MovieDB = new Database(getContext());
        session = new Session(getContext());
        FavoriteMovies();
        return favs;
    }
    private void FavoriteMovies() {
        favsItems = new ArrayList<>();
        final ProgressDialog progressDialog = new ProgressDialog(getContext());
        progressDialog.setMessage("Loading...");
        progressDialog.show();
        Cursor user_favs = MovieDB.getFavs(session.getID());
        if(user_favs.getCount() == 0){
            progressDialog.dismiss();
            noData.setVisibility(View.VISIBLE);
        }
        else {
            noData.setVisibility(View.INVISIBLE);
            progressDialog.dismiss();
            while (user_favs.moveToNext()) {
                FavsItem item = new FavsItem(
                        user_favs.getString(2),
                        user_favs.getString(3),
                        user_favs.getString(4),
                        user_favs.getString(6)
                );
                favsItems.add(item);
            }
            adapter = new FavsAdapter(favsItems, getContext());
            recyclerView.setAdapter(adapter);
        }
    }
    private void refreshContent() {
        FavoriteMovies();
        mSwipeRefreshLayout.setRefreshing(false);
    }
}
