package pdm.mdbg.RegisterLogin.Register;


import android.content.Intent;
import android.database.Cursor;
import android.os.Build;
import android.os.Bundle;
import android.support.annotation.RequiresApi;
import android.support.v4.app.Fragment;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.util.Objects;

import pdm.mdbg.Backend.Database.Database;
import pdm.mdbg.Backend.EMail.SendEmailAsyncTask;
import pdm.mdbg.Backend.Session.Session;
import pdm.mdbg.Frontend.AccountActivity;
import pdm.mdbg.R;

/**
 * A simple {@link Fragment} subclass.
 */
public class RegisterFragment extends Fragment {
    EditText register_name,register_surname,register_email,register_password,register_password_confirm;
    Button btn_signup;
    Database MovieDB;
    private Session session;
    public RegisterFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View SignUp = inflater.inflate(R.layout.fragment_register, container, false);
        final Intent next = new Intent(getContext(), AccountActivity.class);
        session = new Session(getContext());
        MovieDB = new Database(getContext());
        register_name = (EditText) SignUp.findViewById(R.id.register_name);
        register_surname = (EditText) SignUp.findViewById(R.id.register_surname);
        register_email = (EditText) SignUp.findViewById(R.id.register_email);
        register_password = (EditText) SignUp.findViewById(R.id.register_password);
        register_password_confirm = (EditText) SignUp.findViewById(R.id.register_password_confirm);
        btn_signup = (Button) SignUp.findViewById(R.id.btn_signup);
        btn_signup.setOnClickListener(new View.OnClickListener() {
            @RequiresApi(api = Build.VERSION_CODES.KITKAT)
            @Override
            public void onClick(View view) {
                final String name = register_name.getText().toString();
                final String surname = register_surname.getText().toString();
                final String email = register_email.getText().toString();
                final String password = register_password.getText().toString();
                final String password_confirm = register_password_confirm.getText().toString();
                Cursor result = MovieDB.checkEmail(email);
                if (result.getCount() == 0) {
                    if (TextUtils.isEmpty(password) || password.length() < 8) {
                        Toast.makeText(getContext(), "Your password must have at least 8 characters!", Toast.LENGTH_LONG).show();
                    } else {
                        if (Objects.equals(password, password_confirm)) {
                            boolean inserted = MovieDB.addData(name, surname, email, password);
                            if (inserted){
                                new SendEmailAsyncTask(email, name, surname).execute();
                                session.setEMAIL(email);
                                startActivity(next);
                                Toast.makeText(getContext(), "Welcome!", Toast.LENGTH_LONG).show();
                            }else{
                                Toast.makeText(getContext(), "Something went wrong, try again!", Toast.LENGTH_LONG).show();
                            }
                        } else {
                            Toast.makeText(getContext(), "Passwords don't match!", Toast.LENGTH_LONG).show();
                        }
                    }
                }else{
                    Toast.makeText(getContext(), "This email is already taken!", Toast.LENGTH_LONG).show();
                }
            }
        });
        return SignUp;
    }
}
