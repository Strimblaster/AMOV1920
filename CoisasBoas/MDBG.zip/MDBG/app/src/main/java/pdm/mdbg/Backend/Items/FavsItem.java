package pdm.mdbg.Backend.Items;

/**
 * Created by andremelo on 22/01/2017.
 */

public class FavsItem {
    private String movie_id;
    private String movie_thumb;
    private String movie_rating;
    private String movie_date;

    public FavsItem(String movie_id, String movie_thumb, String movie_rating, String movie_date) {
        this.movie_thumb = movie_thumb;
        this.movie_id = movie_id;
        this.movie_rating = movie_rating;
        this.movie_date = movie_date;
    }

    public String getMovie_thumb() {
        return movie_thumb;
    }

    public String getMovie_id() {
        return movie_id;
    }

    public String getMovie_rating() {
        return movie_rating;
    }

    public String getMovie_date() {
        return movie_date;
    }
}
