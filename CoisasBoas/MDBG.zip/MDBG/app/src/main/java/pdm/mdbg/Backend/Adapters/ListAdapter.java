package pdm.mdbg.Backend.Adapters;

import android.content.Context;
import android.content.Intent;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;

import com.squareup.picasso.Picasso;

import java.util.List;

import pdm.mdbg.Backend.Items.ListItem;
import pdm.mdbg.Backend.Session.Session;
import pdm.mdbg.Frontend.MovieDetails.DetailsActivity;
import pdm.mdbg.R;

/**
 * Created by andremelo on 21/01/2017.
 */

public class ListAdapter extends RecyclerView.Adapter<ListAdapter.ViewHolder> {
    private List<ListItem> listItems;
    private Context context;
    private Session session;
    public ListAdapter(List<ListItem> listItems, Context context) {
        this.listItems = listItems;
        this.context = context;
    }


    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view  = LayoutInflater.from(parent.getContext()).inflate(R.layout.list_item,parent,false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(ViewHolder holder, int position) {
        session = new Session(context);
        final ListItem listItem = listItems.get(position);
        Picasso.with(context)
                .load(listItem.getMovie_thumb())
                .into(holder.movieThumb);
        holder.linearLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String id = listItem.getMovie_id();
                String title = listItem.getMovie_title();
                String thumb = listItem.getMovie_thumb();
                session.setMovieID(id);
                session.setMovieTitle(title);
                session.setMovieThumb(thumb);
                Intent intent = new Intent(view.getContext(), DetailsActivity.class);
                intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                context.startActivity(intent);
            }
        });
    }

    @Override
    public int getItemCount() {
        return listItems.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        public ImageView movieThumb;
        public LinearLayout linearLayout;
        public ViewHolder(View itemView) {
            super(itemView);
            movieThumb = (ImageView) itemView.findViewById(R.id.movie_thumb);
            linearLayout = (LinearLayout) itemView.findViewById(R.id.listItemLayout);
        }
    }
}
