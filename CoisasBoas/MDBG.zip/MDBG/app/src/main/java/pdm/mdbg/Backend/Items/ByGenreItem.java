package pdm.mdbg.Backend.Items;

/**
 * Created by andremelo on 22/01/2017.
 */

public class ByGenreItem {
    private String gender_id;
    private String gender_name;

    public ByGenreItem(String gender_id, String gender_name) {
        this.gender_id = gender_id;
        this.gender_name = gender_name;
    }

    public String getGender_id() {
        return gender_id;
    }

    public void setGender_id(String gender_id) {
        this.gender_id = gender_id;
    }

    public String getGender_name() {
        return gender_name;
    }

    public void setGender_name(String gender_name) {
        this.gender_name = gender_name;
    }
}